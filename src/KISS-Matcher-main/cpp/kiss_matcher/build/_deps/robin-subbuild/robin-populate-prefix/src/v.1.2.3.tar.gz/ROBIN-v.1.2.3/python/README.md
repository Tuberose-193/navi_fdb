# Installation 

```
pip install .
```

## Usage
```python
import spark_robin
```

Please refer to `example.py`

## Test 

Once you run

```
python example.py
```

it should not show any errors.


